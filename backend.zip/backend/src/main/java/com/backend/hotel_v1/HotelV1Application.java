package com.backend.hotel_v1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HotelV1Application {

	public static void main(String[] args) {
		SpringApplication.run(HotelV1Application.class, args);
	}

}
